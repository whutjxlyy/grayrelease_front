#!/bin/sh

COLLECTOR_HOME=$1
REST_PORT=$2
CONNECT_TIMEOUT=5
${COLLECTOR_HOME}/sbin/collectorService.sh monitor
COLLECTOR_EXIST=$?
if [ "$COLLECTOR_EXIST" = "120" ];then
    crontab -l | grep -v "${COLLECTOR_HOME}/sbin/bwMonitorStatus.sh ${COLLECTOR_HOME} ${REST_PORT} $3"  | crontab -
    exit 0;
fi

NEED_TO_START_COLLECTOR=$(curl --connect-timeout $CONNECT_TIMEOUT -s "http://localhost:$REST_PORT/status")
if [ $? -ne 0 ]; then
    crontab -l | grep -v "${COLLECTOR_HOME}/sbin/bwMonitorStatus.sh ${COLLECTOR_HOME} ${REST_PORT} $3"  | crontab -
    exit 0;
fi

if [ "$NEED_TO_START_COLLECTOR" = "true" ]; then
    echo "restart collector."
	$COLLECTOR_HOME/shutdown.sh
	sleep 5
	$COLLECTOR_HOME/startup.sh $3
fi
