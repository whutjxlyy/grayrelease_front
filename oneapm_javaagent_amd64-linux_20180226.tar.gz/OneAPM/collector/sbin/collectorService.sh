#!/bin/sh

printUsage () {
    echo "Usage: collectorService.sh (commands ....)"
    echo "commands: "
    echo " start                Start collector by default jdk."
    echo " start JAVA_HOME      Start collector by the specify jdk."
    echo " stop                 Stop collector."
    echo " monitor              Check collector process is alive. It print the process Id if it is alive."
    echo " -h                   Print usage."
    exit 0;

}

if [ "$1" = "" ]; then
    printUsage
fi

if [ "$1" = "-h" ]; then
    printUsage
fi

PRG="$0"
PRGDIR=`dirname "$PRG"`
[ -z "$COLLECTOR_HOME" ] && COLLECTOR_HOME=`cd "$PRGDIR/.." >/dev/null; pwd`

PID_FILE="${COLLECTOR_HOME}/sbin/collector.pid"
COLLECTOR_LOGS_DIR="${COLLECTOR_HOME}/logs"
COLLECTOR_RUNTIME_OPTIONS=" -Xms512M -Xmx1024M"
REST_PORT=$(grep "collector.listen.port" $COLLECTOR_HOME/collector.properties| grep -v "#" | tail -1   | awk -F '=' '{restPort=$2+100;print restPort}')
if [ "$REST_PORT" == "" ]; then
    REST_PORT=19976
fi

if [ ! -d "${COLLECTOR_HOME}/logs" ]; then
    mkdir -p "${COLLECTOR_LOGS_DIR}"
fi

if [ ! -f "$PID_FILE" ]; then
    echo "INIT_PID" > "$PID_FILE"
fi

# process.name  主要用于检测进程是否存在,代码并没有用
if [ "$1" = "start" ]; then

    crontab -l | grep -v "${COLLECTOR_HOME}/sbin/bwMonitorStatus.sh ${COLLECTOR_HOME} ${REST_PORT} $2" | crontab -

    if [ "$2" = "" ]; then
        JRE_HOME="${COLLECTOR_HOME}/jre"
        if [ ! -d "${JRE_HOME}" ]; then
            echo "JRE_HOME is not exist"
            exit -1;
        fi
        echo "Starting collector by default jdk. please execute startup.sh JAVA_HOME if you want to change default jdk."
    else
        JRE_HOME="$2"
        echo "Starting collector by specify jdk. JAVA_HOME: ${JRE_HOME}"
    fi

    _RUNJAVA=${JRE_HOME}/bin/java

	echo "Starting collector...."
	if [ -f "$PID_FILE" ]; then
		if kill -0 `cat "$PID_FILE"` > /dev/null 2>&1; then
			echo "Collector already runing as process `cat "$PID_FILE"`".
			exit 0
		fi
	fi

    eval exec "\"$_RUNJAVA\" ${COLLECTOR_RUNTIME_OPTIONS} -Dprocess.name=ONEAPM_COLLECTOR -jar ${COLLECTOR_HOME}/collector.jar 2> ${COLLECTOR_LOGS_DIR}/error.log 1> /dev/null &"
	if [ $? -eq 0 ]; then
		case "$OSTYPE" in
			*solaris*)
				/bin/echo "${!}\\c" > "$PID_FILE"
				;;
			*)
				/bin/echo -n $! > "$PID_FILE"
				;;
		esac

		if [ $? -eq 0 ];
		then
			sleep 5

			${COLLECTOR_HOME}/sbin/collectorService.sh monitor  > /dev/null 2>&1
            COLLECTOR_EXIST=$?
            if [ "$COLLECTOR_EXIST" = "120" ];then
                echo "Collector started failed!"
                exit 0;
            fi

			echo "Collector started successfully!"
		else
			echo "Failed to write pid"
			exit 1
		fi
	else
		echo "Collector started failure!"
		exit 1
	fi

elif [ "$1" = "monitor" ]; then
    crontab -l | grep -v "${COLLECTOR_HOME}/sbin/bwMonitorStatus.sh ${COLLECTOR_HOME} ${REST_PORT} $2" | crontab -

    COLLECTOR_PID=`cat $PID_FILE`
    PROCESS_ID=$(/bin/ps -fp ${COLLECTOR_PID} | grep "${COLLECTOR_PID}" | grep -v "grep" | awk '{print $2}')
    # Java代码通过退出码来确定进程是否存在
    if [ "${PROCESS_ID}" = "" ]; then
        echo "OneAPM collector was shut down."
        exit 120;
    else
        echo "OneAPM collector is running PID: ${PROCESS_ID}"
    fi
elif [ "$1" = "stop" ]; then
    crontab -l | grep -v "${COLLECTOR_HOME}/sbin/bwMonitorStatus.sh ${COLLECTOR_HOME} ${REST_PORT} $2"  | crontab -

    COLLECTOR_PID=`cat $PID_FILE`
    if [ "$COLLECTOR_PID" = "INIT_PID" ]; then
        echo "OneAPM collector was shut down."
        exit 0;
    fi
    kill -15 $COLLECTOR_PID > /dev/null 2>&1
    echo "Collector stopped successfully!"
else
   printUsage
fi
