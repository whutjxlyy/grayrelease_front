#!/bin/sh

PRG="$0"
PRGDIR=`dirname "$PRG"`
EXECUTABLE=sbin/collectorService.sh

exec "$PRGDIR"/"$EXECUTABLE" start "$@"
