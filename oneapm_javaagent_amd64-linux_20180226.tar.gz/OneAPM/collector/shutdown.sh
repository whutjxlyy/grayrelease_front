#!/bin/sh

COLLECTOR_BASE_PATH=`dirname $0`
${COLLECTOR_BASE_PATH}/sbin/collectorService.sh stop
